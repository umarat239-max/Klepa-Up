# Разовый скрипт: разбивает исходный index.html на public/index.html, css/app.css, js/app.js и assets/*
import re,hashlib,os,base64,sys
src=sys.argv[1];out='public'
os.makedirs(out+'/assets',exist_ok=True)
s=open(src,encoding='utf-8').read()
EXT={'font/woff2':'woff2','image/webp':'webp','image/png':'png','image/jpeg':'jpg','image/gif':'gif','image/svg+xml':'svg'}
def blob(m):
    mime,d=m.group(1),m.group(2)
    if len(d)<2000 or mime not in EXT: return m.group(0)
    n=hashlib.sha1(d.encode()).hexdigest()[:12]+'.'+EXT[mime]
    open(f'{out}/assets/{n}','wb').write(base64.b64decode(d)); return '/assets/'+n
s=re.sub(r'data:([a-z/+\-0-9]+);base64,([A-Za-z0-9+/=]+)',blob,s)
css=re.search(r'<style>(.*?)</style>',s,re.S)
js=re.search(r'<script>\n(window\.start=.*?)</script></body></html>',s,re.S)
def rep(t,a,b):
    assert a in t,a[:60]; return t.replace(a,b,1)
j=js.group(1)
j=rep(j,"const REF={bot:'',app:'',api:'',per:1000};","const REF={bot:(window.KCFG||{}).bot||'',app:(window.KCFG||{}).app||'',api:location.origin,per:1000};")
j=re.sub(r"key:'sk-or-v1-[A-Za-z0-9]+'","key:''",j); assert 'sk-or-' not in j
j=rep(j,"url:'https://openrouter.ai/api/v1/chat/completions'","url:'/api/ai'")
j=rep(j,"'Authorization':'Bearer '+AI.key","'x-init':(tg&&tg.initData)||''")
j=rep(j,"if(!P){toast('Промокод не найден');hp('error');return}","if(!P){if(window.kupPromo)return kupPromo(v);toast('Промокод не найден');hp('error');return}")
j=rep(j,"renderRef();setTimeout(()=>refSync(true),2600);","renderRef();setTimeout(()=>refSync(true),2600);window.kupInit&&kupInit({S,save,bal,toast,hp,tg,U,fmt,G,nmx,renderInv,$});")
open(out+'/css/app.css','w',encoding='utf-8').write(css.group(1))
open(out+'/js/app.js','w',encoding='utf-8').write(j)
h=s.replace(css.group(0),'<link rel="stylesheet" href="/css/app.css"><link rel="stylesheet" href="/css/extra.css">')
h=h.replace(js.group(0),'<script src="/js/extra.js"></script><script src="/js/app.js"></script></body></html>')
h=rep(h,'<title>Klepa Up</title>','<title>Klepa Up</title><script src="/config.js"></script>')
open(out+'/index.html','w',encoding='utf-8').write(h)
print('html',len(h),'css',len(css.group(1)),'js',len(j),'assets',len(os.listdir(out+'/assets')))
